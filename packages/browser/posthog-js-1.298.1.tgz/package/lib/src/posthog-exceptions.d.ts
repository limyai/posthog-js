import { PostHog } from './posthog-core';
import { CaptureResult, Properties, RemoteConfig } from './types';
import { ErrorTracking } from '@posthog/core';
export declare function buildErrorPropertiesBuilder(): ErrorTracking.ErrorPropertiesBuilder;
export declare class PostHogExceptions {
    private readonly _instance;
    private _suppressionRules;
    private _errorPropertiesBuilder;
    constructor(instance: PostHog);
    onRemoteConfig(response: RemoteConfig): void;
    private get _captureExtensionExceptions();
    buildProperties(input: unknown, metadata?: {
        handled?: boolean;
        syntheticException?: Error;
    }): ErrorTracking.ErrorProperties;
    sendExceptionEvent(properties: Properties): CaptureResult | undefined;
    private _matchesSuppressionRule;
    private _isExtensionException;
    private _isPostHogException;
    private _isExceptionList;
}
